FOOTBALL SYNC ANDROID — SOURCE STARTER

This is an Android Studio source project, not an APK.

What it currently does:
- Opens https://www.football.com/ng/ in a large Android WebView.
- Shows five compact account tabs.
- Shows target-profit, stake placeholder, and PLACE ALL in one row.
- Shows a confirmation dialog.

What it does NOT do yet:
- Reuse your Chrome login. Android WebView has its own cookie/session storage.
- Provide five isolated authenticated account sessions.
- Detect selections or odds on Football.com.
- Calculate a live stake from detected odds.
- Synchronise or submit bets.

Do not enter credentials into any third-party app build unless you trust the source and understand its permissions. This starter is intentionally not wired to submit bets. Before adding account automation, check Football.com's terms and test whether multiple sessions are allowed.

Build:
1. Open this folder as a project in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the resulting debug APK on your Android phone.

If you only have an Android phone, this source project cannot be compiled by Chrome. You would need a compatible Android IDE/build environment; I can guide you through checking one, but this ZIP itself is not installable.
