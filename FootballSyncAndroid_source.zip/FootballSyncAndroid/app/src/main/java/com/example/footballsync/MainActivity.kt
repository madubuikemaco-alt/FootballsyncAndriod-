package com.example.footballsync

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var targetInput: EditText
    private lateinit var stakeText: TextView
    private lateinit var statusText: TextView
    private var currentOdds: Double? = null
    private val green = Color.rgb(25, 164, 99)
    private val dark = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(25, 38, 48)
    private val muted = Color.rgb(159, 176, 186)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (savedInstanceState == null) webView.loadUrl("https://www.football.com/ng/")
        else webView.restoreState(savedInstanceState)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(8, 8, 8, 6)
        }

        val header = TextView(this).apply {
            text = "⚽ Football Sync"
            textSize = 19f
            setTextColor(Color.WHITE)
            setPadding(6, 5, 6, 8)
        }
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 1..5) {
            val tab = Button(this).apply {
                text = "Account $i"
                textSize = 10f
                isAllCaps = false
                setOnClickListener {
                    if (i == 1) {
                        statusText.text = "Account 1 is the only connected WebView in this starter."
                    } else {
                        statusText.text = "Account $i is not connected yet. Separate secure sessions need to be implemented and tested."
                        Toast.makeText(this@MainActivity, "Account $i not connected yet", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(0, 42, 1f).apply {
                setMargins(2, 0, 2, 6)
            })
        }
        root.addView(tabs)

        webView = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 6, 0, 0)
        }
        val targetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        targetBox.addView(label("TARGET PROFIT"))
        targetInput = EditText(this).apply {
            setText("7500")
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            setPadding(8, 4, 8, 4)
            setBackgroundColor(panel)
        }
        targetBox.addView(targetInput, LinearLayout.LayoutParams(-1, 42))
        controls.addView(targetBox, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0,0,5,0) })

        val stakeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        stakeBox.addView(label("STAKE (AUTO)"))
        stakeText = TextView(this).apply {
            text = "—"
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            setPadding(8, 4, 8, 4)
            setBackgroundColor(panel)
        }
        stakeBox.addView(stakeText, LinearLayout.LayoutParams(-1, 42))
        controls.addView(stakeBox, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0,0,5,0) })

        val place = Button(this).apply {
            text = "PLACE ALL"
            textSize = 11f
            isAllCaps = true
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { showConfirmation() }
        }
        controls.addView(place, LinearLayout.LayoutParams(-2, 42))
        root.addView(controls)

        statusText = TextView(this).apply {
            text = "Main account view loaded here. Odds detection and multi-account sync are not connected."
            textSize = 10f
            setTextColor(muted)
            setPadding(3, 5, 3, 0)
        }
        root.addView(statusText)
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 9f
        setTextColor(muted)
        setPadding(2, 0, 2, 3)
    }

    private fun showConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Confirm placement?")
            .setMessage("This starter does not submit bets. Football.com connection is for viewing and manual use only until account synchronisation and permitted automation are separately implemented and tested.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
