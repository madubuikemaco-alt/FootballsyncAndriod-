package com.footballsynchronizer.app;
import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.webkit.*;
import android.widget.*;
import android.graphics.Color;
import org.json.JSONObject;

public abstract class AccountWebActivity extends Activity {
 protected abstract int accountNumber();
 private WebView web; private TextView status; private BroadcastReceiver receiver;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout root=new LinearLayout(this); root.setOrientation(1);
  TextView h=new TextView(this); h.setText("FOOTBALL.COM — ACCOUNT "+accountNumber()); h.setTextColor(Color.WHITE); h.setBackgroundColor(Color.rgb(20,28,42)); h.setPadding(16,14,16,14); root.addView(h);
  status=new TextView(this); status.setText(accountNumber()==1?"MASTER: tap an outcome to sync":"FOLLOWER: waiting for Account 1"); status.setPadding(12,8,12,8); root.addView(status);
  web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.addJavascriptInterface(new SyncBridge(),"FootballSync");
  web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String u){if(accountNumber()==1)installMasterListener();}});
  web.setWebChromeClient(new WebChromeClient()); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
  if(accountNumber()!=1){receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String p=i.getStringExtra("selection");if(p!=null)applySelection(p);}};
   IntentFilter f=new IntentFilter("com.footballsynchronizer.SELECTION");
   if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);}
  web.loadUrl("https://www.football.com/ng/");
 }
 private void installMasterListener(){
  String js="(function(){if(window.__fsInstalled)return;window.__fsInstalled=true;document.addEventListener('click',function(e){var n=e.target;if(!n)return;var c=n.closest('button,[role=button],a,[data-op],.outcome,.odd')||n;var label=(c.innerText||c.getAttribute('aria-label')||c.title||'').trim();if(!label||label.length>90)return;var parts=[],p=c;for(var k=0;k<4&&p;k++,p=p.parentElement){var t=(p.innerText||'').trim();if(t&&t.length<700)parts.push(t);}window.FootballSync.sendSelection(JSON.stringify({label:label,context:parts}));},true);})();";
  web.evaluateJavascript(js,null);
 }
 private class SyncBridge{
  @JavascriptInterface public void sendSelection(String json){try{JSONObject o=new JSONObject(json);String label=o.optString("label","");if(label.isEmpty())return;
   Intent i=new Intent("com.footballsynchronizer.SELECTION");i.setPackage(getPackageName());i.putExtra("selection",o.toString());sendBroadcast(i);
   runOnUiThread(()->status.setText("Sent selection to Accounts 2–5: "+label));
  }catch(Exception ignored){}}
 }
 private void applySelection(String payload){
  try{JSONObject o=new JSONObject(payload);String label=o.optString("label","");String context=o.optJSONArray("context")==null?"":o.optJSONArray("context").toString();
   String js="(function(){var label="+JSONObject.quote(label)+",ctx="+JSONObject.quote(context)+";var norm=s=>String(s||'').replace(/\\s+/g,' ').trim().toLowerCase();var a=Array.from(document.querySelectorAll('button,[role=button],a,[data-op],.outcome,.odd')).filter(e=>norm(e.innerText||e.getAttribute('aria-label')||e.title)===norm(label));if(ctx){var tok=ctx.toLowerCase().split(/[^a-z0-9]+/).filter(x=>x.length>3);a=a.filter(e=>{var p=e,t='';for(var k=0;k<4&&p;k++,p=p.parentElement)t+=' '+(p.innerText||'');var h=tok.filter(x=>t.toLowerCase().includes(x));return h.length>=Math.min(2,tok.length);});}if(a.length===1){a[0].click();return 'MATCHED';}return a.length?'AMBIGUOUS':'NOT FOUND';})();";
   web.evaluateJavascript(js,r->status.setText("Sync "+(r==null?"UNKNOWN":r.replace("\"",""))+": "+label));
  }catch(Exception e){status.setText("Could not read selection");}
 }
 @Override protected void onDestroy(){if(receiver!=null)try{unregisterReceiver(receiver);}catch(Exception ignored){}if(web!=null)web.destroy();super.onDestroy();}
}
