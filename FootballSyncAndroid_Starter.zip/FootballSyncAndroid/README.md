# Football Sync Android starter
Five Android account screens, each in its own Android process with a separate WebView data-directory suffix (Android 9+). Each screen opens https://www.football.com/ng/.

Build: GitHub → Actions → Build Football Sync APK → Run workflow. Download the FootballSync-debug-apk artifact after a successful run.

Important: This starter provides isolated browser storage only. It does not copy selections, scrape odds, submit bets, or cash out. Football.com may block embedded WebViews or restrict automated use. It has not yet been built or tested on a physical device; successful compilation does not guarantee site compatibility.
