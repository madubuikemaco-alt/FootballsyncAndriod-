package com.footballsynchronizer.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.widget.*;
import android.graphics.Color;
public abstract class AccountWebActivity extends Activity {
 protected abstract int accountNumber();
 @Override public void onCreate(Bundle b) {
  super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(1);
  TextView h=new TextView(this); h.setText("FOOTBALL.COM — ACCOUNT "+accountNumber()); h.setTextColor(-1); h.setBackgroundColor(Color.rgb(20,28,42)); h.setPadding(16,14,16,14); l.addView(h);
  WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient()); l.addView(w,new LinearLayout.LayoutParams(-1,0,1)); setContentView(l); w.loadUrl("https://www.football.com/ng/");
 }
}
