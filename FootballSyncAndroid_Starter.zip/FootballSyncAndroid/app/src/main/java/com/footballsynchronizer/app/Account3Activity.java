package com.footballsynchronizer.app;
public class Account3Activity extends AccountWebActivity {
 @Override protected int accountNumber() { return 3; }
}
