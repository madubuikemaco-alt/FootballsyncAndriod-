package com.footballsynchronizer.app;
public class Account2Activity extends AccountWebActivity {
 @Override protected int accountNumber() { return 2; }
}
