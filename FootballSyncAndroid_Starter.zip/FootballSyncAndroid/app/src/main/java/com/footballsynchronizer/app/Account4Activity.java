package com.footballsynchronizer.app;
public class Account4Activity extends AccountWebActivity {
 @Override protected int accountNumber() { return 4; }
}
