package com.footballsynchronizer.app;
public class Account5Activity extends AccountWebActivity {
 @Override protected int accountNumber() { return 5; }
}
