package com.footballsynchronizer.app;
import android.app.Application;
import android.os.Build;
import android.webkit.WebView;
public class FootballSyncApp extends Application {
 @Override public void onCreate() {
  if (Build.VERSION.SDK_INT >= 28) {
   String p = Application.getProcessName();
   String suffix = (p != null && p.contains(":")) ? p.substring(p.lastIndexOf(':') + 1) : "main";
   WebView.setDataDirectorySuffix(suffix);
  }
  super.onCreate();
 }
}
