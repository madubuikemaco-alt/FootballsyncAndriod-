package com.footballsynchronizer.app;
public class Account1Activity extends AccountWebActivity {
 @Override protected int accountNumber() { return 1; }
}
