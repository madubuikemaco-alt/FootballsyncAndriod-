package com.footballsynchronizer.app;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(24,30,24,24); l.setBackgroundColor(Color.rgb(16,20,29));
  TextView t=new TextView(this); t.setText("FOOTBALL SYNC"); t.setTextColor(-1); t.setTextSize(25); t.setGravity(Gravity.CENTER); l.addView(t);
  TextView n=new TextView(this); n.setText("Open each account in its own isolated browser session. Sign in separately."); n.setTextColor(Color.LTGRAY); n.setPadding(0,16,0,16); l.addView(n);
  Class<?>[] a={Account1Activity.class,Account2Activity.class,Account3Activity.class,Account4Activity.class,Account5Activity.class};
  for(int i=0;i<5;i++){ final int x=i; Button bt=new Button(this); bt.setText("OPEN ACCOUNT "+(i+1)); bt.setOnClickListener(v->startActivity(new android.content.Intent(this,a[x]))); l.addView(bt); }
  TextView d=new TextView(this); d.setText("Account 1 sends selected outcomes to Accounts 2–5. Bet submission is disabled."); d.setTextColor(0xffffcc78); d.setPadding(0,20,0,0); l.addView(d);
  setContentView(l);
 }
}
